const express = require('express');
const OpenAI = require('openai');
const path = require('path');
const app = express();
app.use(express.json({limit:'12mb'}));
app.use(express.static(path.join(__dirname,'www')));
app.post('/api/analyze-food', async (req,res)=>{
  if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:'OPENAI_API_KEY is not configured'});
  const {image,notes=''}=req.body||{};
  if(typeof image!=='string'||!image.startsWith('data:image/')) return res.status(400).json({error:'A food image is required'});
  try {
    const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const response=await client.responses.create({model:process.env.OPENAI_VISION_MODEL||'gpt-4.1-mini',input:[{role:'user',content:[{type:'input_text',text:`حلل صورة الطعام وقدّر مكونات الوجبة والحصة والسعرات الحرارية والبروتين والكاربوهيدرات والدهون. ملاحظات المستخدم: ${notes}. كن حذراً واذكر تقديراً تقريبياً ولا تدّع دقة غير ممكنة. أرجع JSON فقط بالمفاتيح: name (اسم عربي), portion (وصف الحصة), calories (number), protein (number grams), carbs (number grams), fat (number grams).`},{type:'input_image',image_url:image}]}],text:{format:{type:'json_object'}}});
    const raw=response.output_text; const data=JSON.parse(raw); for(const k of ['calories','protein','carbs','fat']) if(!Number.isFinite(Number(data[k]))) throw new Error('Invalid nutrition output');
    res.json({name:String(data.name||'وجبة'),portion:String(data.portion||'تقدير تقريبي'),calories:Number(data.calories),protein:Number(data.protein),carbs:Number(data.carbs),fat:Number(data.fat)});
  } catch(e){console.error('food analysis failed:',e.message);res.status(502).json({error:'Food analysis failed'});}
});
const port=process.env.PORT||3000;app.listen(port,()=>console.log(`Proteink running on http://localhost:${port}`));
